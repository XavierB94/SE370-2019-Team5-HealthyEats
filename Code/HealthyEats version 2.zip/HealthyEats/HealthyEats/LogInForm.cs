﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class LogInForm : Form
    {
        public LogInForm()
        {
            InitializeComponent();
        }

        private void Label5_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignInForm sf = new SignInForm();
            sf.ShowDialog();
            this.ShowDialog();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            ForgetUsernameForm uf = new ForgetUsernameForm();
            uf.ShowDialog();
            this.ShowDialog();
        }
    }
}
