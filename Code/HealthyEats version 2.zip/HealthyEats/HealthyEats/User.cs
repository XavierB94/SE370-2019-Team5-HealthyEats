﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace HealthyEats
{
    class User
    {
        private string _userName;
        private string _password;
        private string _firstName;
        private string _lastName;
        private string _access;

        public User()
        {
            _firstName = "";
            _lastName = "";
            _userName = "";
            _password = "";
            _access = "";  
        }

        // Checks if the user is already in the database
        private int UserExists(string username, string password)
        {
            DBConnection db = new DBConnection("HealthyEats");                              // Sets update DB connection server
            string sql = "spUserCheck";

            using (SqlConnection conn = new SqlConnection(db.getConnection()))              // Creates DB connection
            {
                SqlCommand cmd = new SqlCommand(sql, conn);                                 // Pass in SQL command with DB connection
                cmd.CommandType = CommandType.StoredProcedure;                              // Set command type to stored procedure

                cmd.Parameters.AddWithValue("@Username", SqlDbType.NVarChar).Value = username;       // Add in parameter value of stored procedure
                cmd.Parameters.AddWithValue("@Password", SqlDbType.NVarChar).Value = password;       // Add in parameter value of stored procedure

                conn.Open();
                IDataReader dr = cmd.ExecuteReader();
                dr.Read();
                var status = dr.GetValue(0);

                conn.Close();
                return Int32.Parse(status.ToString());
            }
        }

        public bool addUser(string firstname = "", string lastname="",  string birthday = "", string username="", string password="", string access="")
        {
            string message, caption;

            //input error checking
            if (firstname == "" || lastname == "" || birthday == "" || username == "" || password == "" || access == "")
            {
                message = "User information is imcomplete.";
                caption = "User Sign In Error";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                if (UserExists(username,password) < 0)
                {
                    DBConnection db = new DBConnection("HealthyEats");
                    string sql = "spAddUser";

                    using (SqlConnection conn = new SqlConnection(db.getConnection()))
                    {
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@firstName", SqlDbType.NVarChar).Value = firstname;
                        cmd.Parameters.Add("@lastName", SqlDbType.NVarChar).Value = lastname;
                        cmd.Parameters.Add("@birthday", SqlDbType.Date).Value = birthday;
                        cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = username;
                        cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;
                        cmd.Parameters.Add("@Access", SqlDbType.NVarChar).Value = access;

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        message = "User is added successfully.";
                        caption = "User Sign In";
                        return true;
                    }
                }
                else
                {
                    message = "The user is already in the system.";
                    caption = "User Sign In";
                    MessageBox.Show(message, caption);
                    return false;
                }

            }
        }

        public string getUsername(string firstName, string lastName, string birthday) {
       
            if (firstName == "" || lastName == "" || birthday == "")
            {
                string message, caption;
                message = "User information is imcomplete.";
                caption = "Forget Username";
                MessageBox.Show(message, caption);
                return null;
            }
            
            
            return null;
        }

    }
}
