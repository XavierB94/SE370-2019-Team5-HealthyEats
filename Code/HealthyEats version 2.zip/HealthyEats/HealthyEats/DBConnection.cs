﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthyEats
{
    class DBConnection
    {
        private string _connection;

        public DBConnection()
        {
            _connection = null;
        }

        public DBConnection(string database)
        {
            switch (database)
            {
                case "HealthyEats":
                    _connection = "Server=sedb.cvrxht9shj5o.us-east-2.rds.amazonaws.com;Database=HealthyEats;User ID=masteradmin; Password=L3t$g03At!";
                    break;
            }
        }

        public string getConnection()
        {
            return _connection;
        }
    }
}
