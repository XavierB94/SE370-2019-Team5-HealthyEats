﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class SignInForm : Form
    {
        public SignInForm()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string firstname;
            string lastname;
            string birthday;
            string username;
            string password;
            string access;
            User user = new User();
            
            firstname = this.tbFirstName.Text.ToString();
            lastname = this.tbLastName.Text.ToString();
            birthday = this.dtBirthday.Text.ToString();
            username = this.tbUsername.Text.ToString();
            password = this.tbPassword.Text.ToString();
            access = this.cbAccess.Text.ToString();

            // Adds new user
            if(user.addUser(firstname, lastname, birthday, username, password, access) == true)
            {
                this.Close();
            }
            
        }
    }
}
