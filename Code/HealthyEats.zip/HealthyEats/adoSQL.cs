﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace HealthyEats
{
    class ADOSQL
    { 
        public void loadDatatoComboBox(string database, string sql, ComboBox cb)
        {
            DBConnection db = new DBConnection(database);

            using (SqlConnection conn = new SqlConnection(db.getConnection()))
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                IDataReader data = cmd.ExecuteReader();

                while(data.Read())
                {
                    cb.Items.Add(data.GetString(0).ToString());
                }

                conn.Close();
            }
        }


    }
}
