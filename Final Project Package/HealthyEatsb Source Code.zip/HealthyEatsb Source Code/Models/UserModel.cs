﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;


namespace HealthyEats
{
    class UserModel
    {

        //checks if user is already in the database
        public int isUserExists(string username, string password)
        {
            DBConnection db = new DBConnection("HealthyEats");                                      // Sets update DB connection server
            string sql = "spUserCheck";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))                      // Creates DB connection
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);                                         // Pass in SQL command with DB connection
                    cmd.CommandType = CommandType.StoredProcedure;                                      // Set command type to stored procedure

                    cmd.Parameters.AddWithValue("@Username", SqlDbType.NVarChar).Value = username;      // Add in parameter value of stored procedure
                    cmd.Parameters.AddWithValue("@Password", SqlDbType.NVarChar).Value = password;      // Add in parameter value of stored procedure

                    conn.Open();
                    IDataReader dr = cmd.ExecuteReader();
                    dr.Read();

                    var status = dr.GetValue(0);

                    conn.Close();
                    return Int32.Parse(status.ToString());
                }
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        // add new user account
        public void addUser(string firstname, string lastname, string birthday, string username, string password)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spAddUser";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@firstName", SqlDbType.NVarChar).Value = firstname;
                    cmd.Parameters.Add("@lastName", SqlDbType.NVarChar).Value = lastname;
                    cmd.Parameters.Add("@birthday", SqlDbType.Date).Value = birthday;
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = username;
                    cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // retrieve username
        public string getUsername(string firstname, string lastname, string birthday)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetUsername";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@firstName", SqlDbType.NVarChar).Value = firstname;
                    cmd.Parameters.Add("@lastName", SqlDbType.NVarChar).Value = lastname;
                    cmd.Parameters.Add("@birthday", SqlDbType.Date).Value = birthday;

                    conn.Open();
                    string username = (string) cmd.ExecuteScalar();
                    conn.Close();

                    return username;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //retrieve password
        public string getPassword(string username, string birthday)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetPassword";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = username;
                    cmd.Parameters.Add("@birthday", SqlDbType.Date).Value = birthday;

                    conn.Open();
                    string password = (string)cmd.ExecuteScalar();
                    conn.Close();

                    return password;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Gets user profile
        public DataTable getUserProfile(int userID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetUserProfile";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@userID", SqlDbType.NVarChar).Value = userID;
                    conn.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    da.Dispose();
                    conn.Close();

                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Updates user profile
        public void updateUserProfile(int userID, string firstname, string lastname, string birthday, string username, string password)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spUpdateUserProfile";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@userID", SqlDbType.NVarChar).Value = userID;
                    cmd.Parameters.Add("@firstName", SqlDbType.NVarChar).Value = firstname;
                    cmd.Parameters.Add("@lastName", SqlDbType.NVarChar).Value = lastname;
                    cmd.Parameters.Add("@birthday", SqlDbType.Date).Value = birthday;
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = username;
                    cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
