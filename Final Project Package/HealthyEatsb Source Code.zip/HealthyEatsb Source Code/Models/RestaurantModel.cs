﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace HealthyEats
{
    class RestaurantModel
    {

        //This method returns the restaurant menu
        public DataTable getRestaurantMenu(int restaurantID, int userID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetFoodMenu";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@restaurantID", SqlDbType.Int).Value = restaurantID;
                    cmd.Parameters.Add("@userID", SqlDbType.Int).Value = userID;

                    conn.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    da.Dispose();
                    conn.Close();

                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //This method returns the restaurant menu
        public DataTable getRestaurantInfoList(string city, string state, int userID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetRestaurantProfile";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = city;
                    cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = state;
                    cmd.Parameters.Add("@userID", SqlDbType.Int).Value = userID;
                    
                    conn.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    da.Dispose();
                    conn.Close();

                    

                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Add favorite restaurant to profile
        public void addFavoriteRestaurant(int restaurantID, int userID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spAddFavoriteRestaurant";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@restaurantID", SqlDbType.NVarChar).Value = restaurantID;
                    cmd.Parameters.Add("@userID", SqlDbType.NVarChar).Value = userID;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Deletes favorite restaurant from profile
        public void deleteFavoriteRestaurant(int restaurantID, int userID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spDeleteFavoriteRestaurant";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@restaurantID", SqlDbType.NVarChar).Value = restaurantID;
                    cmd.Parameters.Add("@userID", SqlDbType.NVarChar).Value = userID;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //This method returns the restaurant review
        public DataTable getRestaurantReview(int restaurantID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetReview";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@restaurantID", SqlDbType.Int).Value = restaurantID;

                    conn.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    da.Dispose();
                    conn.Close();

                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        // Add restaurant review
        public void addRestaurantReview(int restaurantID, string comment, int rate)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spAddRestaurantReview";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@restaurantID", SqlDbType.Int).Value = restaurantID;
                    cmd.Parameters.Add("@comment", SqlDbType.NVarChar).Value = comment;
                    cmd.Parameters.Add("@rate", SqlDbType.Int).Value = rate;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }


        }

        // Gets favorite restaurant list
        public DataTable getFavoriteRestaurant(string city, string state, int userID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetFavoriteRestaurant";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@city", SqlDbType.NVarChar).Value = city;
                    cmd.Parameters.Add("@state", SqlDbType.NVarChar).Value = state;
                    cmd.Parameters.Add("@userID", SqlDbType.Int).Value = userID;

                    conn.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    da.Dispose();
                    conn.Close();

                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
