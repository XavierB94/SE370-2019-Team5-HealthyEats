﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace HealthyEats
{
    class MedicalModel
    {
        // Gets medical condition list
        public DataTable getMedicalList()
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spGetMedicalList";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    da.Dispose();
                    conn.Close();

                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Add medical condition to profile
        public void addMedicalInfo(int userID, int medicalConditionID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spAddMedicalInfo";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@userID", SqlDbType.NVarChar).Value = userID;
                    cmd.Parameters.Add("@medicalConditionID", SqlDbType.NVarChar).Value = medicalConditionID;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Delete medical condition to profile
        public void deleteMedicalInfo(int userID, int medicalConditionID)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spDeleteMedicalInfo";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@userID", SqlDbType.NVarChar).Value = userID;
                    cmd.Parameters.Add("@medicalConditionID", SqlDbType.NVarChar).Value = medicalConditionID;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Add medical condition
        public void addMedicalCondition(string condition)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spAddMedicalCondition";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@condition", SqlDbType.NVarChar).Value = condition;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Edit medical condition
        public void editMedicalCondition(int medicalConditionID, string condition)
        {
            DBConnection db = new DBConnection("HealthyEats");
            string sql = "spEditMedicalCondition";

            try
            {
                using (SqlConnection conn = new SqlConnection(db.getConnection()))
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@condition", SqlDbType.NVarChar).Value = condition;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
