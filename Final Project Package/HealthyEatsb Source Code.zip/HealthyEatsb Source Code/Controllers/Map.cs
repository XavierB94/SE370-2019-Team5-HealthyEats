﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GoogleDirections;
using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using GMap.NET.MapProviders;
using System.Drawing;
using System.Windows.Forms;

namespace HealthyEats
{
    class Map
    {
        // Converts address to point coordinates in the map
        public PointLatLng addressToPointLocation(string address)
        {
            Geocoder g = new Geocoder("AIzaSyA-kYE3F7zshinQD35jhEmtevN6SDSBotU");
            var info = g.Geocode(address);
            double lattitude = 0, longtitude = 0;

            foreach (GoogleDirections.Location a in info)
            {
                lattitude = (double)a.LatLng.Latitude;
                longtitude = (double)a.LatLng.Longitude;
            }

            return new PointLatLng(lattitude, longtitude);
        }

        // Gets a pointer to the map
        public GMapOverlay getMarkerOverlay(string address1, bool primary)
        {
            PointLatLng p1 = addressToPointLocation(address1);
            GMapOverlay markerOverlay = new GMapOverlay("marker");

            if (primary == true)
            {
                // point in the map using marker
                GMapMarker marker1 = new GMarkerGoogle(p1, GMarkerGoogleType.green_big_go);
                markerOverlay.Markers.Add(marker1);
            }
            else
            {
                // marker setup
                Bitmap icon = new Bitmap("Food Icon map.png");
                Bitmap resized = new Bitmap(icon, new Size(icon.Width / 28, icon.Height / 28));

                // point in the map using marker
                GMapMarker marker1 = new GMarkerGoogle(p1, resized);
                markerOverlay.Markers.Add(marker1);
            }

            return markerOverlay;
        }

        // Gets two pointer to the map (start and end point)
        public GMapOverlay getMarkerOverlay(string address1, string address2)
        {
            PointLatLng p1 = addressToPointLocation(address1);
            PointLatLng p2 = addressToPointLocation(address2);

            // marker setup
            Bitmap icon = new Bitmap("Food Icon map.png");
            Bitmap resized = new Bitmap(icon, new Size(icon.Width / 28, icon.Height / 28));

            // point in the map using marker
            GMapOverlay markerOverlay = new GMapOverlay("marker");
            GMapMarker marker2 = new GMarkerGoogle(p1, GMarkerGoogleType.green_big_go);
            GMapMarker marker1 = new GMarkerGoogle(p2, resized);
            
            markerOverlay.Markers.Add(marker1);
            markerOverlay.Markers.Add(marker2);

            return markerOverlay;
        }

        // Gets direction to the map (Not working/disabled due to free subscription)
        public GMapOverlay getRouteOverlay(string address1, string address2)
        {
            PointLatLng p1 = addressToPointLocation(address1);
            PointLatLng p2 = addressToPointLocation(address2);

            // add route
            MapRoute route = GoogleMapProvider.Instance.GetRoute(p1, p2, true, false, 15);
            GMapRoute r = new GMapRoute(route.Points, "My Route")
            {
                Stroke = new Pen(Color.Red, 5)
            };

            GMapOverlay routes = new GMapOverlay("routes");
            routes.Routes.Add(r);

            return routes;
        }

        // Sets address to map
        public void setMapLocation(string address, GMapControl gmMap, bool primary)
        {
            if (address == "") return;

            //to remove markers
            if (primary == true)
            {
                while (gmMap.Overlays.Count > 0)
                {
                    gmMap.Overlays.RemoveAt(0);
                }
            }
            else
            {
                while (gmMap.Overlays.Count > 1)
                {
                    gmMap.Overlays.RemoveAt(1);
                }
            }

            // map setup
            gmMap.DragButton = MouseButtons.Left;
            gmMap.MapProvider = GoogleMapProvider.Instance;
            GMaps.Instance.Mode = AccessMode.ServerOnly;
            PointLatLng p1 = addressToPointLocation(address);

            gmMap.Position = p1;
            gmMap.Overlays.Add(getMarkerOverlay(address, primary));
            if (primary == true)
                gmMap.Zoom = 15;
            else
                gmMap.Zoom = 13;

            gmMap.Refresh();
        }
    }
}
