﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace HealthyEats
{
    class Restaurant
    {
        private DataTable _restaurantTable;
        private DataTable _favoriteRestaurantTable;

        public Restaurant()
        {
            _restaurantTable = new DataTable();
            _favoriteRestaurantTable = new DataTable();
        }

        // Gets restaurant list
        public void getRestaurantInfoList(string address, int userID, ListView lv)
        {

            if (address == "") return;

            RestaurantModel rm = new RestaurantModel();
            DataTable dt = new DataTable();
            string city, state;
            string[] temp;
            string[] separator;

            // Loads restaurant list ==========================================================
            separator = new string[] { "Text: ", ", " };
            temp = address.Split(separator, System.StringSplitOptions.RemoveEmptyEntries);

            if (temp.Length == 1)
            {
                string caption = "Address Error";
                string message = "Please use comma to separate the city and state.";
                MessageBox.Show(message, caption);
                return;
            }

            city = temp[0];
            state = temp[1];
            dt = rm.getRestaurantInfoList(city, state, userID);
            _restaurantTable = dt;

            lv.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                String[] temp1 = new String[] {
                                            dt.Rows[i].Field<string>("RestaurantName"),
                                            dt.Rows[i].Field<string>("CuisineType"),
                                            dt.Rows[i].Field<string>("Webpage"),
                                            dt.Rows[i].Field<string>("Address")
                                            };
                ListViewItem lvi = new ListViewItem(temp1);
                lv.Items.Add(lvi);
            }
        }

        // Gets rerstaurant menu
        public void getRestaurantFoodMenu(string restaurant, int userID, ListView lv)
        {
            RestaurantModel rm = new RestaurantModel();
            DataTable dt = new DataTable();
            int restaurantID = getRestaurantID(restaurant);
            dt = rm.getRestaurantMenu(restaurantID, userID);

            //This is for Menu
            lv.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ListViewItem lvi = new ListViewItem(dt.Rows[i].Field<string>("FoodName"));
                lv.Items.Add(lvi);
            }
        }

        // Gets restaurant review
        public void getRestaurantReview(string restaurant, ListView lv)
        {
            RestaurantModel rm = new RestaurantModel();
            DataTable dt = new DataTable();
            int restaurantID = getRestaurantID(restaurant);
            dt = rm.getRestaurantReview(restaurantID);

            //This section gets the restaurant review
            lv.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                String[] temp1 = new String[] { dt.Rows[i].Field<string>("Comment"), dt.Rows[i].Field<int>("Rate").ToString() };
                ListViewItem lvi = new ListViewItem(temp1);
                lv.Items.Add(lvi);
            }
        }

        // Gets restaurant ID
        public int getRestaurantID(string restaurant)
        {
            DataTable dt = _restaurantTable;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string t = dt.Rows[i].Field<string>("RestaurantName").ToString();

                if (restaurant == t)
                {
                    return dt.Rows[i].Field<int>("RestaurantID");
                }
            }

            return 0;
        }

        // Gets favorite restaurant list
        public void getFavoriteRestaurant(string address, int userID, ListView lv)
        {
            if (address == "") return;

            RestaurantModel rm = new RestaurantModel();
            DataTable dt = new DataTable();
            string city, state;
            string[] temp;
            string[] separator;

            // Loads restaurant list ==========================================================
            separator = new string[] { "Text: ", ", " };
            temp = address.Split(separator, System.StringSplitOptions.RemoveEmptyEntries);

            if(temp.Length == 1)
            {
                return;
            }

            city = temp[0];
            state = temp[1];
            dt = rm.getFavoriteRestaurant(city, state, userID);
            _favoriteRestaurantTable = dt;

            lv.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                String[] temp1 = new String[] {
                                            dt.Rows[i].Field<string>("RestaurantName"),
                                            dt.Rows[i].Field<string>("CuisineType"),
                                            dt.Rows[i].Field<string>("Webpage"),
                                            dt.Rows[i].Field<string>("Address")
                                            };
                ListViewItem lvi = new ListViewItem(temp1);
                lv.Items.Add(lvi);
            }
        }

        // Adds new review
        public void addRestaurantReview(string restaurant, string comment, int rate)
        {
            RestaurantModel restaurantmodel = new RestaurantModel();
            string message, caption;
            int restaurantID = getRestaurantID(restaurant);

            //input error checking
            if (restaurantID == 0 || comment == "" || rate == 0)
            {
                message = "Restaurant review is incomplete.";
                caption = "Restaurant Review Error";
                MessageBox.Show(message, caption);
            }
            else
            {
                try
                {
                    restaurantmodel.addRestaurantReview(restaurantID, comment, rate);
                    message = "You have successfully added a restaurant review!";
                    caption = "Restaurant Review";
                    MessageBox.Show(message, caption);
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while adding Restaurant Review.");
                }
            }
        }

        // Adds restaurant to favorites 
        public void addFavoriteRestaurant(int restaurantID, int userID)
        {
            RestaurantModel restaurantmodel = new RestaurantModel();
            string message, caption;

            //input error checking
            if (restaurantID == 0 || userID == 0)
            {
                message = "Favorite Restaurant input is incomplete.";
                caption = "Favorite Restaurant Error";
                MessageBox.Show(message, caption);
            }
            else
            {
                try
                {
                    restaurantmodel.addFavoriteRestaurant(restaurantID, userID);
                    message = "You have successfully added a restaurant to your favorites list!";
                    caption = "Add Favorite Restaurant";
                    MessageBox.Show(message, caption);
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while adding Favorite Restaurant.");
                }
            }

        }

        // Deletes restaurant from favorites
        public void deleteFavoriteRestaurant(int restaurantID, int userID)
        {
            RestaurantModel restaurantmodel = new RestaurantModel();
            string message, caption;

            //input error checking
            if (restaurantID == 0 || userID == 0)
            {
                message = "Delete Favorite Restaurant input is incomplete.";
                caption = "Delete Favorite Restaurant Error";
                MessageBox.Show(message, caption);
            }
            else
            {
                try
                {
                    restaurantmodel.deleteFavoriteRestaurant(restaurantID, userID);
                    message = "You have successfully deleted a restaurant from your favorites list!";
                    caption = "Delete Favorite Restaurant";
                    MessageBox.Show(message, caption);
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while deleting Favorite Restaurant.");
                }
            }
        }


    }
}
