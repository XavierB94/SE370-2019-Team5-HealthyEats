﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace HealthyEats
{
    class User
    {
        // Checks if the user is already in the database
        public int userExists(string username, string password)
        {
            UserModel usermodel = new UserModel();
            string message, caption;
            int userStatus;

            try
            {
                userStatus = usermodel.isUserExists(username, password);
                if (userStatus < 0)
                {
                    message = "Invalid username and Password.";
                    caption = "User Log In";
                    MessageBox.Show(message, caption);
                    return -1;
                }
                else if (userStatus == 0)
                {
                    message = "Invalid password.";
                    caption = "User Log In";
                    MessageBox.Show(message, caption);
                    return 0;
                }
                else
                {
                    return userStatus;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error.");
                return -1;
            }
        }

        //Retrieve Password
        public bool getPassword(string username, string birthday)
        {
            string message, caption, password;

            if (username == "" || birthday == "")
            {
                message = "Invalid Username or Birthday";
                caption = "Forget Password";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                try
                {
                    UserModel um = new UserModel();
                    password = um.getPassword(username, birthday);

                    if (password == null)
                    {
                        message = "Invalid Username or Birthday";
                        caption = "Forget Password";
                        MessageBox.Show(message, caption);
                        return false;
                    }
                    else
                    {
                        message = "Password: " + password;
                        caption = "Forget Password";
                        MessageBox.Show(message, caption);
                        return true;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while retrieving password.");
                    return false;
                }
            }
        }

        //Retrieve Username
        public bool getUsername(string firstname, string lastname, string birthday)
        {
            string message, caption, username;

            if (firstname == "" || lastname == "" || birthday == "")
            {
                
                message = "Invalid Information";
                caption = "Forget Username";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                try
                {
                    UserModel um = new UserModel();
                    username = um.getUsername(firstname, lastname, birthday);

                    if (username == null)
                    {
                        message = "Invalid First Name, Last Name, or Birthday.";
                        caption = "Forget Password";
                        MessageBox.Show(message, caption);
                        return false;
                    }
                    else
                    {
                        message = "Username: " + username;
                        caption = "Forget Username";
                        MessageBox.Show(message, caption);
                        return true;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while retrieving username.");
                    return false;
                }
            }
        }

        //Add new user account
        public bool addUser(string firstname = "", string lastname="",  string birthday = "", string username="", string password="")
        {
            UserModel usermodel = new UserModel();
            string message, caption;
            DateTime datetime = DateTime.Today;

            //input error checking
            if (firstname == "" || lastname == "" || birthday == "" || username == "" || password == "" || DateTime.TryParse(birthday,out datetime) == false)
            {
                message = "User information is imcomplete.";
                caption = "User Sign In Error";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                try
                {
                    int userStatus = usermodel.isUserExists(username, password);

                    if (userStatus < 0)
                    {
                        usermodel.addUser(firstname, lastname, birthday, username, password);

                        message = "You have successfully created an account!";
                        caption = "User Sign In";
                        MessageBox.Show(message, caption);

                        return true;
                    }
                    else
                    {
                        message = "The user is already in the system.";
                        caption = "User Sign In";
                        MessageBox.Show(message, caption);
                        return false;
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while adding new user.");
                    return false;
                }
            }
        }

        // Gets user profile
        public DataTable getUserProfile(int userID)
        {
            string message, caption;

            try
            {
                if (userID == 0)
                {

                    message = "User Profile is imcomplete.";
                    caption = "Get User Profile";
                    MessageBox.Show(message, caption);
                    return null;
                }

                UserModel um = new UserModel();
                DataTable dt = um.getUserProfile(userID);
                return dt;
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error while retrieving User Profile.");
                return null;
            }
            
        }

        // Udpates user profile
        public void updateUserProfile(int userID, string firstname, string lastname, string birthday, string username, string password)
        {
            string message, caption;

            if (userID == 0 || firstname == "" || lastname == "" || birthday == "" || username == "" || password == "")
            {

                message = "User Profile is imcomplete.";
                caption = "Update User Profile";
                MessageBox.Show(message, caption);
            }
            else
            {
                try
                {
                    UserModel um = new UserModel();
                    um.updateUserProfile(userID, firstname, lastname, birthday, username, password);
                    message = "User Profile is updated in the system.";
                    caption = "Update User Profile";
                    MessageBox.Show(message, caption);
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while updating User Profile.");
                }
            }
        }
    }
}
