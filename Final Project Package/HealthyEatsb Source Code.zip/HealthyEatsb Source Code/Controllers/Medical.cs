﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace HealthyEats
{
    class Medical
    {
        private DataTable _conditionTable;

        public Medical()
        {
            _conditionTable = new DataTable();
        }

        // Gets medical condition list
        public bool getMedicalList(ComboBox cb)
        {
            MedicalModel mm = new MedicalModel();
            DataTable dt = mm.getMedicalList();
            _conditionTable = dt;

            for(int  i = 0; i < dt.Rows.Count; i++)
            {
                cb.Items.Add(dt.Rows[i].Field<string>("Type").ToString());
            }

            return true;
        }

        // Add mendical condition to profile
        public bool addMedicalInfo(int userID, string medicalCondition)
        {
            MedicalModel medicalmodel = new MedicalModel();
            string message, caption;

            //input error checking
            if (userID == 0 || medicalCondition == "")
            {
                message = "Add Medical Info is imcomplete.";
                caption = "Add Medical Info Error";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                try
                {
                    int medicalConditionID = getConditionID(medicalCondition);
                    medicalmodel.addMedicalInfo(userID, medicalConditionID);
                    message = "The Medical Info is already in the system.";
                    caption = "Add Medical Info";
                    MessageBox.Show(message, caption);
                    return false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while adding the Medical Info.");
                    return false;
                }
            }
        }

        // Deletes medical condition from profile
        public bool deleteMedicalInfo(int userID, string medicalCondition)
        {
            MedicalModel medicalmodel = new MedicalModel();
            string message, caption;

            //input error checking
            if (userID == 0 || medicalCondition == "")
            {
                message = "Delete Medical Info is imcomplete.";
                caption = "Delete Medical Info Error";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                try
                {
                    int medicalConditionID = getConditionID(medicalCondition);
                    medicalmodel.deleteMedicalInfo(userID, medicalConditionID);
                    message = "The Medical Info is already been delete from the system.";
                    caption = "Delete Medical Info";
                    MessageBox.Show(message, caption);
                    return false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while deleting the Medical Info.");
                    return false;
                }
            }
        }

        // Add medical condition to list
        public bool addMedicalCondition(string condition)
        {
            MedicalModel medicalmodel = new MedicalModel();
            string message, caption;

            //input error checking
            if (condition == "")
            {
                message = "Add Medical Condition is imcomplete.";
                caption = "Add Medical Condition Error";
                MessageBox.Show(message, caption);
                return false;
            }
            else
            {
                try
                {
                    medicalmodel.addMedicalCondition(condition);
                    message = "The Medical Condition is already in the system.";
                    caption = "Add Medical Condition";
                    MessageBox.Show(message, caption);
                    return false;
                }
                catch (Exception)
                {
                    MessageBox.Show("Database Error while adding the Medical Condition.");
                    return false;
                }
            }
        }

        // Gets medical condition ID
        public int getConditionID(string condition)
        {
            DataTable dt = _conditionTable;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string t = dt.Rows[i].Field<string>("Type").ToString();

                if (condition == t)
                {
                    return dt.Rows[i].Field<int>("MedicalConditionID");
                }
            }

            return 0;
        }
    }
}
