﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class uf_LogIn : Form
    {
        public uf_LogIn()
        {
            InitializeComponent();
        }

        // Launch forgot password form
        private void LblForgotPassword_Click(object sender, EventArgs e)
        {
            uf_ForgetPassword fp = new uf_ForgetPassword();
            this.Hide();
            fp.ShowDialog();
            fp.Close();
            this.Show();
        }

        // Launch forgot username form
        private void LblForgotUsername_Click(object sender, EventArgs e)
        {
            uf_ForgetUsername fu = new uf_ForgetUsername();
            this.Hide();
            fu.ShowDialog();
            fu.Close();
            this.Show();
        }

        // Launch sign up form
        private void LblSignUp_Click(object sender, EventArgs e)
        {
            uf_SignIn sp = new uf_SignIn();
            this.Hide();
            sp.ShowDialog();
            sp.Close();
            this.Show();
        }

        // Launch home page
        private void BtnLogIn_Click(object sender, EventArgs e)
        {
            User user = new User();
            int userID;

            userID = user.userExists(this.txtUsername.Text.ToString(), this.txtPassword.Text.ToString());

           if (userID > 0)
            {
                uf_HomePage hp = new uf_HomePage(userID);

                this.Hide();
                hp.ShowDialog();
                hp.Close();
                this.Close();
            }
        }

    }
}
