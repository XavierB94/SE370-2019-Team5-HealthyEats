﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoogleDirections;
using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using GMap.NET.MapProviders;

namespace HealthyEats
{
    public partial class uf_HomePage : Form
    {
        private Map _map;
        private Restaurant _restaurant;
        private int _userID;
        private string _address;
        private string _selectedRestaurant;
        private string _selectedFavRestaurant;

        public uf_HomePage(int userID)
        {
            InitializeComponent();
            _map = new Map();
            _restaurant = new Restaurant();
            _userID = userID;
            _address = "";
            _selectedRestaurant = "";
            _selectedFavRestaurant = "";
        }

        private void Uf_HomePage_Load(object sender, EventArgs e)
        {
            gmMap.ShowCenter = false;
        }

        // Current Location set-up
        private void Button2_Click(object sender, EventArgs e)
        {
            this.lvReview.Items.Clear();
            this.lvMenu.Items.Clear();
            this.lvRestaurant.Items.Clear();
            this.lvFavRestaurant.Items.Clear();

            string address = this.txtCurrentLocation.Text;

            _address = address;
            _selectedRestaurant = "";
            _selectedFavRestaurant = "";

            _map.setMapLocation(address, gmMap, true);           
            _restaurant.getRestaurantInfoList(address, _userID, this.lvRestaurant);
            _restaurant.getFavoriteRestaurant(address, _userID, this.lvFavRestaurant);
        }

        // Gets menu per restaurant selected in the restaurant listview
        private void LvRestaurant_MouseClick(object sender, MouseEventArgs e)
        {

            DataTable dt = new DataTable();
            string restaurant = this.lvRestaurant.SelectedItems[0].Text;
            _restaurant.getRestaurantFoodMenu(restaurant, _userID, this.lvMenu);
            _restaurant.getRestaurantReview(restaurant, this.lvReview);
            _selectedRestaurant = restaurant;
            _selectedFavRestaurant = "";

            string address = this.lvRestaurant.SelectedItems[0].SubItems[3].Text;
            _map.setMapLocation(address, gmMap, false);
        }

        // Gets menu per favorite restaurant selected in the restaurant listview
        private void LvFavRestaurant_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                string restaurant = this.lvFavRestaurant.SelectedItems[0].Text;
                _restaurant.getRestaurantFoodMenu(restaurant, _userID, this.lvMenu);
                _restaurant.getRestaurantReview(restaurant, this.lvReview);
                _selectedRestaurant = "";
                _selectedFavRestaurant = restaurant;

                string address = this.lvFavRestaurant.SelectedItems[0].SubItems[3].Text;
                _map.setMapLocation(address, gmMap, false);
            }
            catch (Exception)
            {   
                return;
            }
            
        }

        // Add review
        private void BtnSubmitReview_Click(object sender, EventArgs e)
        {
            string comment;
            int rating;
            string restaurant;

            if(_selectedRestaurant == "")
            {
                string caption = "Add Feedabck";
                string message = "Please select restaurant from Restaurant List.";
                MessageBox.Show(message, caption);
                return;
            }

            int i = 0;
            if(int.TryParse(this.txtRate.Text, out i) == false)
            {
                string caption = "Add Feedabck";
                string message = "Rating must be numeric.";
                MessageBox.Show(message, caption);
                return;
            }
            comment = this.txtComment.Text;
            rating = int.Parse(this.txtRate.Text);
            restaurant = this.lvRestaurant.SelectedItems[0].Text;

            _restaurant.addRestaurantReview(restaurant, comment, rating);
            _restaurant.getRestaurantReview(restaurant, this.lvReview);

        }

        // Add favorite
        private void BtnFavorite_Click(object sender, EventArgs e)
        {
            string restaurant;
            int restaurantID;

            if (_selectedRestaurant == "")
            {
               string message = "Please select Restaurant in the List";
               string caption = "Add to Favorites";
               MessageBox.Show(message, caption);
            }
            else
            {
                restaurant = _selectedRestaurant;
                restaurantID = _restaurant.getRestaurantID(restaurant);
                _restaurant.addFavoriteRestaurant(restaurantID, _userID);
                _restaurant.getFavoriteRestaurant(_address, _userID, lvFavRestaurant);
            }
            _selectedFavRestaurant = "";
            _selectedRestaurant = "";
        }

        // Delete favorite
        private void BtnRemoveFav_Click(object sender, EventArgs e)
        {
            string restaurant;
            int restaurantID;
            _selectedRestaurant = "";

            if (_selectedFavRestaurant == "")
            {
                string message = "Please select Restaurant in the List";
                string caption = "Add to Favorites";
                MessageBox.Show(message, caption);
            }
            else
            {
                restaurant = _selectedFavRestaurant;
                restaurantID = _restaurant.getRestaurantID(restaurant);
                _restaurant.deleteFavoriteRestaurant(restaurantID, _userID);
                _restaurant.getFavoriteRestaurant(_address, _userID, lvFavRestaurant);
            }
            _selectedFavRestaurant = "";
        }

        // Launch medical profile form
        private void MedicalProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            uf_Medical m = new uf_Medical(_userID);
            this.Hide();
            m.ShowDialog();
            m.Close();
            this.Show();
        }

        private void UserProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataTable dt;
            User us = new User();
            dt = us.getUserProfile(_userID);
            uf_SignIn s = new uf_SignIn(_userID, dt);
            s.Text = "Update Profile Form";

            this.Hide();
            s.ShowDialog();
            this.Show();
        }
    }
}
