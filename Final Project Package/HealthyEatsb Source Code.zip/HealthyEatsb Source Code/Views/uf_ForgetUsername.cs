﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class uf_ForgetUsername : Form
    {
        public uf_ForgetUsername()
        {
            InitializeComponent();
        }

        // Gets username
        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            User user = new User();
            if (user.getUsername(this.txtFirstname.Text.ToString(), this.txtLastname.Text.ToString(), this.txtBirthday.Text.ToString()) == true)
                this.Close();
        }
    }
}
