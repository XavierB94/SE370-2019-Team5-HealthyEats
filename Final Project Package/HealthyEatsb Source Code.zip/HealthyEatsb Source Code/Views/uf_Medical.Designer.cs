﻿namespace HealthyEats
{
    partial class uf_Medical
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtAddMedCondition = new System.Windows.Forms.TextBox();
            this.btnAddMedCondition = new System.Windows.Forms.Button();
            this.cbMedCondition = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddMedInfo = new System.Windows.Forms.Button();
            this.btnDeleteMedInfo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Add Medical Condition";
            // 
            // txtAddMedCondition
            // 
            this.txtAddMedCondition.BackColor = System.Drawing.SystemColors.Info;
            this.txtAddMedCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddMedCondition.Location = new System.Drawing.Point(21, 41);
            this.txtAddMedCondition.Name = "txtAddMedCondition";
            this.txtAddMedCondition.Size = new System.Drawing.Size(472, 30);
            this.txtAddMedCondition.TabIndex = 7;
            // 
            // btnAddMedCondition
            // 
            this.btnAddMedCondition.Location = new System.Drawing.Point(260, 77);
            this.btnAddMedCondition.Name = "btnAddMedCondition";
            this.btnAddMedCondition.Size = new System.Drawing.Size(233, 30);
            this.btnAddMedCondition.TabIndex = 6;
            this.btnAddMedCondition.Text = "Add New  Med Condition";
            this.btnAddMedCondition.UseVisualStyleBackColor = true;
            this.btnAddMedCondition.Click += new System.EventHandler(this.BtnAddMedCondition_Click);
            // 
            // cbMedCondition
            // 
            this.cbMedCondition.BackColor = System.Drawing.SystemColors.Info;
            this.cbMedCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMedCondition.FormattingEnabled = true;
            this.cbMedCondition.Items.AddRange(new object[] {
            "Berries Allergy",
            "Diabetis",
            "Fish Allergy",
            "Heart Disease",
            "High Blood Pressure",
            "Lactose Intolerance",
            "Penuts Allergy",
            "Shellfish Allergy",
            "Soy Allergy",
            "Tree Nuts Allergy"});
            this.cbMedCondition.Location = new System.Drawing.Point(22, 133);
            this.cbMedCondition.Name = "cbMedCondition";
            this.cbMedCondition.Size = new System.Drawing.Size(471, 33);
            this.cbMedCondition.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Medical Condition";
            // 
            // btnAddMedInfo
            // 
            this.btnAddMedInfo.Location = new System.Drawing.Point(21, 172);
            this.btnAddMedInfo.Name = "btnAddMedInfo";
            this.btnAddMedInfo.Size = new System.Drawing.Size(233, 30);
            this.btnAddMedInfo.TabIndex = 11;
            this.btnAddMedInfo.Text = "Add Med Condition to Profile";
            this.btnAddMedInfo.UseVisualStyleBackColor = true;
            this.btnAddMedInfo.Click += new System.EventHandler(this.BtnAddMedInfo_Click);
            // 
            // btnDeleteMedInfo
            // 
            this.btnDeleteMedInfo.Location = new System.Drawing.Point(260, 172);
            this.btnDeleteMedInfo.Name = "btnDeleteMedInfo";
            this.btnDeleteMedInfo.Size = new System.Drawing.Size(233, 30);
            this.btnDeleteMedInfo.TabIndex = 12;
            this.btnDeleteMedInfo.Text = "Remove Med Condition to Profile";
            this.btnDeleteMedInfo.UseVisualStyleBackColor = true;
            this.btnDeleteMedInfo.Click += new System.EventHandler(this.BtnDeleteMedInfo_Click);
            // 
            // uf_Medical
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HealthyEats.Properties.Resources.Background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(520, 222);
            this.Controls.Add(this.btnDeleteMedInfo);
            this.Controls.Add(this.btnAddMedInfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMedCondition);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAddMedCondition);
            this.Controls.Add(this.btnAddMedCondition);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "uf_Medical";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Medical Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAddMedCondition;
        private System.Windows.Forms.Button btnAddMedCondition;
        private System.Windows.Forms.ComboBox cbMedCondition;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddMedInfo;
        private System.Windows.Forms.Button btnDeleteMedInfo;
    }
}