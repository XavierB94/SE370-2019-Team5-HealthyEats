﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class uf_ForgetPassword : Form
    {
        public uf_ForgetPassword()
        {
            InitializeComponent();
        }

        // Gets password
        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            User u = new User();
            if (u.getPassword(txtUsername.Text.ToString(), txtBirthday.Text.ToString()) == true)
                Close();
        }
    }
}
