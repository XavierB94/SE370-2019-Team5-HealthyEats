﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class uf_SignIn : Form
    {
        private int _userID;

        public uf_SignIn()
        {
            InitializeComponent();
            _userID = 0;
            this.btnUpdate.Visible = false;
        }

        public uf_SignIn(int userID, DataTable dt)
        {
            InitializeComponent();
            _userID = userID;
            this.btnSignIn.Visible = false;
            loadInfo(dt);
        }

        // Loads data
        private void loadInfo(DataTable dt)
        {
            this.txtFirstname.Text = dt.Rows[0].Field<string>("FirstName").ToString();
            this.txtLastname.Text = dt.Rows[0].Field<string>("LastName").ToString();
            this.txtBirthday.Text = dt.Rows[0].Field<string>("Birthday").ToString();
            this.txtUsername.Text = dt.Rows[0].Field<string>("Username").ToString();
            this.txtPassword.Text = dt.Rows[0].Field<string>("Password").ToString();
        }

        // Submits user's profile as new user
        private void BtnSignIn_Click(object sender, EventArgs e)
        {
            string firstname;
            string lastname;
            string birthday;
            string username;
            string password;
            User user = new User();

            firstname = txtFirstname.Text;
            lastname = txtLastname.Text;
            birthday = txtBirthday.Text;
            username = txtUsername.Text;
            password = txtPassword.Text;

            // Adds new user
            if (user.addUser(firstname, lastname, birthday, username, password) == true)
                Close();
        }

        // Submits user profile update
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            string firstname;
            string lastname;
            string birthday;
            string username;
            string password;
            User user = new User();

            firstname = txtFirstname.Text;
            lastname = txtLastname.Text;
            birthday = txtBirthday.Text;
            username = txtUsername.Text;
            password = txtPassword.Text;

            // Adds new user
            user.updateUserProfile(_userID, firstname, lastname, birthday, username, password);
            Close();
        }

    }
}
