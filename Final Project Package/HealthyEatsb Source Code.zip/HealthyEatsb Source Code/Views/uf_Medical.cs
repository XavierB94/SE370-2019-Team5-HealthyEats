﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthyEats
{
    public partial class uf_Medical : Form
    {
        private int _userID;
        private Medical _medical;

        public uf_Medical(int userID)
        {
            InitializeComponent();
            _userID = userID;
            _medical = new Medical();
            getMedicalList();
        }

        // Refresh the form
        private void getMedicalList()
        {
            this.txtAddMedCondition.Clear();
            this.cbMedCondition.Items.Clear();
            _medical.getMedicalList(cbMedCondition);
        }

        // Add new medical condition
        private void BtnAddMedCondition_Click(object sender, EventArgs e)
        {
            string condition = this.txtAddMedCondition.Text;
            _medical.addMedicalCondition(condition);
            getMedicalList();
        }

        // add medical condition to user profile
        private void BtnAddMedInfo_Click(object sender, EventArgs e)
        {
            string condition = this.cbMedCondition.Text;
            _medical.addMedicalInfo(_userID,condition);
            getMedicalList();
        }

        // delete medical condition to user profile
        private void BtnDeleteMedInfo_Click(object sender, EventArgs e)
        {
            string condition = this.cbMedCondition.Text;
            _medical.deleteMedicalInfo(_userID, condition);
            getMedicalList();
        }
    }
}
