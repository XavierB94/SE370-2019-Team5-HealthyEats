﻿namespace HealthyEats
{
    partial class uf_HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gmMap = new GMap.NET.WindowsForms.GMapControl();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCurrentLocation = new System.Windows.Forms.TextBox();
            this.lvRestaurant = new System.Windows.Forms.ListView();
            this.chRestaurant = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chWeb = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label3 = new System.Windows.Forms.Label();
            this.lvReview = new System.Windows.Forms.ListView();
            this.chReview = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chRating = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lvMenu = new System.Windows.Forms.ListView();
            this.chMenu = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label8 = new System.Windows.Forms.Label();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.btnSubmitReview = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lvFavRestaurant = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnFavorite = new System.Windows.Forms.Button();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRemoveFav = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.medicalProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gmMap
            // 
            this.gmMap.Bearing = 0F;
            this.gmMap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gmMap.CanDragMap = true;
            this.gmMap.EmptyTileColor = System.Drawing.Color.Navy;
            this.gmMap.GrayScaleMode = false;
            this.gmMap.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gmMap.LevelsKeepInMemmory = 5;
            this.gmMap.Location = new System.Drawing.Point(892, 114);
            this.gmMap.MarkersEnabled = true;
            this.gmMap.MaxZoom = 20;
            this.gmMap.MinZoom = 2;
            this.gmMap.MouseWheelZoomEnabled = true;
            this.gmMap.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gmMap.Name = "gmMap";
            this.gmMap.NegativeMode = false;
            this.gmMap.PolygonsEnabled = true;
            this.gmMap.RetryLoadTile = 0;
            this.gmMap.RoutesEnabled = true;
            this.gmMap.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gmMap.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gmMap.ShowTileGridLines = false;
            this.gmMap.Size = new System.Drawing.Size(570, 640);
            this.gmMap.TabIndex = 0;
            this.gmMap.Zoom = 17D;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(444, 46);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "Current Location";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Current Location";
            // 
            // txtCurrentLocation
            // 
            this.txtCurrentLocation.BackColor = System.Drawing.SystemColors.Info;
            this.txtCurrentLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentLocation.Location = new System.Drawing.Point(22, 50);
            this.txtCurrentLocation.Name = "txtCurrentLocation";
            this.txtCurrentLocation.Size = new System.Drawing.Size(414, 30);
            this.txtCurrentLocation.TabIndex = 4;
            // 
            // lvRestaurant
            // 
            this.lvRestaurant.BackColor = System.Drawing.SystemColors.Info;
            this.lvRestaurant.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chRestaurant,
            this.chType,
            this.chWeb,
            this.chAddress});
            this.lvRestaurant.GridLines = true;
            this.lvRestaurant.Location = new System.Drawing.Point(22, 114);
            this.lvRestaurant.Name = "lvRestaurant";
            this.lvRestaurant.Size = new System.Drawing.Size(847, 190);
            this.lvRestaurant.TabIndex = 6;
            this.lvRestaurant.UseCompatibleStateImageBehavior = false;
            this.lvRestaurant.View = System.Windows.Forms.View.Details;
            this.lvRestaurant.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LvRestaurant_MouseClick);
            // 
            // chRestaurant
            // 
            this.chRestaurant.Text = "Restaurant";
            this.chRestaurant.Width = 250;
            // 
            // chType
            // 
            this.chType.Text = "Type";
            this.chType.Width = 90;
            // 
            // chWeb
            // 
            this.chWeb.Text = "Web Page";
            this.chWeb.Width = 200;
            // 
            // chAddress
            // 
            this.chAddress.Text = "Address";
            this.chAddress.Width = 300;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Restaurant";
            // 
            // lvReview
            // 
            this.lvReview.BackColor = System.Drawing.SystemColors.Info;
            this.lvReview.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chReview,
            this.chRating});
            this.lvReview.GridLines = true;
            this.lvReview.Location = new System.Drawing.Point(23, 542);
            this.lvReview.Name = "lvReview";
            this.lvReview.Size = new System.Drawing.Size(414, 212);
            this.lvReview.TabIndex = 8;
            this.lvReview.UseCompatibleStateImageBehavior = false;
            this.lvReview.View = System.Windows.Forms.View.Details;
            // 
            // chReview
            // 
            this.chReview.Text = "Review";
            this.chReview.Width = 340;
            // 
            // chRating
            // 
            this.chRating.Text = "Rating";
            this.chRating.Width = 70;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 519);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Reviews";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 332);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Favorites";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(897, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Map";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(451, 519);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "Menu";
            // 
            // lvMenu
            // 
            this.lvMenu.BackColor = System.Drawing.SystemColors.Info;
            this.lvMenu.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chMenu});
            this.lvMenu.GridLines = true;
            this.lvMenu.Location = new System.Drawing.Point(455, 542);
            this.lvMenu.Name = "lvMenu";
            this.lvMenu.Size = new System.Drawing.Size(414, 212);
            this.lvMenu.TabIndex = 13;
            this.lvMenu.UseCompatibleStateImageBehavior = false;
            this.lvMenu.View = System.Windows.Forms.View.Details;
            // 
            // chMenu
            // 
            this.chMenu.Text = "Food Menu";
            this.chMenu.Width = 410;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 770);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 20);
            this.label8.TabIndex = 16;
            this.label8.Text = "Add Feedback";
            // 
            // txtComment
            // 
            this.txtComment.BackColor = System.Drawing.SystemColors.Info;
            this.txtComment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComment.Location = new System.Drawing.Point(23, 790);
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(347, 30);
            this.txtComment.TabIndex = 15;
            // 
            // btnSubmitReview
            // 
            this.btnSubmitReview.Location = new System.Drawing.Point(455, 784);
            this.btnSubmitReview.Name = "btnSubmitReview";
            this.btnSubmitReview.Size = new System.Drawing.Size(135, 36);
            this.btnSubmitReview.TabIndex = 17;
            this.btnSubmitReview.Text = "Submit";
            this.btnSubmitReview.UseVisualStyleBackColor = true;
            this.btnSubmitReview.Click += new System.EventHandler(this.BtnSubmitReview_Click);
            // 
            // lvFavRestaurant
            // 
            this.lvFavRestaurant.BackColor = System.Drawing.SystemColors.Info;
            this.lvFavRestaurant.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvFavRestaurant.GridLines = true;
            this.lvFavRestaurant.Location = new System.Drawing.Point(21, 355);
            this.lvFavRestaurant.Name = "lvFavRestaurant";
            this.lvFavRestaurant.Size = new System.Drawing.Size(847, 161);
            this.lvFavRestaurant.TabIndex = 19;
            this.lvFavRestaurant.UseCompatibleStateImageBehavior = false;
            this.lvFavRestaurant.View = System.Windows.Forms.View.Details;
            this.lvFavRestaurant.SelectedIndexChanged += new System.EventHandler(this.LvFavRestaurant_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Restaurant";
            this.columnHeader1.Width = 250;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Type";
            this.columnHeader2.Width = 90;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Web Page";
            this.columnHeader3.Width = 200;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Address";
            this.columnHeader4.Width = 300;
            // 
            // btnFavorite
            // 
            this.btnFavorite.Location = new System.Drawing.Point(691, 78);
            this.btnFavorite.Name = "btnFavorite";
            this.btnFavorite.Size = new System.Drawing.Size(178, 30);
            this.btnFavorite.TabIndex = 20;
            this.btnFavorite.Text = "Add to Favorites";
            this.btnFavorite.UseVisualStyleBackColor = true;
            this.btnFavorite.Click += new System.EventHandler(this.BtnFavorite_Click);
            // 
            // txtRate
            // 
            this.txtRate.BackColor = System.Drawing.SystemColors.Info;
            this.txtRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRate.Location = new System.Drawing.Point(376, 790);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(61, 30);
            this.txtRate.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(372, 767);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "Rating";
            // 
            // btnRemoveFav
            // 
            this.btnRemoveFav.Location = new System.Drawing.Point(690, 319);
            this.btnRemoveFav.Name = "btnRemoveFav";
            this.btnRemoveFav.Size = new System.Drawing.Size(178, 30);
            this.btnRemoveFav.TabIndex = 23;
            this.btnRemoveFav.Text = "Remove From Favorites";
            this.btnRemoveFav.UseVisualStyleBackColor = true;
            this.btnRemoveFav.Click += new System.EventHandler(this.BtnRemoveFav_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(263, 36);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(262, 32);
            this.toolStripMenuItem1.Text = "toolStripMenuItem1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(1225, 13);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(249, 33);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.medicalProfileToolStripMenuItem,
            this.userProfileToolStripMenuItem});
            this.settingsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.4F);
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(91, 29);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // medicalProfileToolStripMenuItem
            // 
            this.medicalProfileToolStripMenuItem.Name = "medicalProfileToolStripMenuItem";
            this.medicalProfileToolStripMenuItem.Size = new System.Drawing.Size(217, 30);
            this.medicalProfileToolStripMenuItem.Text = "Medical Profile";
            this.medicalProfileToolStripMenuItem.Click += new System.EventHandler(this.MedicalProfileToolStripMenuItem_Click);
            // 
            // userProfileToolStripMenuItem
            // 
            this.userProfileToolStripMenuItem.Name = "userProfileToolStripMenuItem";
            this.userProfileToolStripMenuItem.Size = new System.Drawing.Size(217, 30);
            this.userProfileToolStripMenuItem.Text = "User Profile";
            this.userProfileToolStripMenuItem.Click += new System.EventHandler(this.UserProfileToolStripMenuItem_Click);
            // 
            // uf_HomePage
            // 
            this.BackgroundImage = global::HealthyEats.Properties.Resources.Background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1483, 834);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnRemoveFav);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.btnFavorite);
            this.Controls.Add(this.lvFavRestaurant);
            this.Controls.Add(this.btnSubmitReview);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtComment);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lvMenu);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lvReview);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lvRestaurant);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCurrentLocation);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.gmMap);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "uf_HomePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home Page";
            this.Load += new System.EventHandler(this.Uf_HomePage_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListView listView1;
        private GMap.NET.WindowsForms.GMapControl map;
        private System.Windows.Forms.Button button1;
        private GMap.NET.WindowsForms.GMapControl gmMap;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCurrentLocation;
        private System.Windows.Forms.ListView lvRestaurant;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvReview;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListView lvMenu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Button btnSubmitReview;
        private System.Windows.Forms.ColumnHeader chRestaurant;
        private System.Windows.Forms.ColumnHeader chType;
        private System.Windows.Forms.ColumnHeader chWeb;
        private System.Windows.Forms.ColumnHeader chAddress;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ListView lvFavRestaurant;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader chReview;
        private System.Windows.Forms.ColumnHeader chRating;
        private System.Windows.Forms.ColumnHeader chMenu;
        private System.Windows.Forms.Button btnFavorite;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRemoveFav;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem medicalProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userProfileToolStripMenuItem;
    }
}